# Windows 11 Free RDP One Hour
Demo Lab with Windows 11 VM: https://lms.godeploy.it/DemoLabs/Register
# Note
- Using ngrok maybe can get unlimited session timeout (More than 1 Hour), so dont kill this script process at your Remote Desktop. You can just minimize or hide the script window
# Tutorial 
- Register Ngrok at https://ngrok.com and save your ngrok authtoken.<br>
- Download and extract this Repository to your Remote Desktop.<br>
- Change Ngrok Authtoken [ xxx ] in [ start.bat ] to your own ngrok authtoken then save the file.<br>
- Run [ start.bat ] by double clicking file, right click run as admin or run using cmd.<br>
- Check your Ngrok tunnel at https://dashboard.ngrok.com/tunnels/agents and connect Remote Desktop using showed ngrok host:port. <br>Ex : xxx.tcp.xxx.ngrok.io:xxx

# Other Free Remote Desktop Tutorial
- https://github.com/kmille36/Windows-11-VPS/
